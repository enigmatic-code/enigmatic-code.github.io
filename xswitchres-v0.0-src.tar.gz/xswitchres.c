/* -*-C-*-
*******************************************************************************
*
* File:         xswitchres.c
* RCS:          $Header: $
* Description:  Programatically Switch XFree86 Resolutions
* Author:       Jim Randell
* Created:      Mon Nov 29 17:47:14 1999
* Modified:     Mon Nov 29 19:07:34 1999 (Jim Randell) jim@slashdot.f9.co.uk
* Language:     C
* Package:      N/A
* Status:       Experimental (Do Not Distribute)
*
* (C) Copyright 1999, Jim Randell, all rights reserved.
*
*******************************************************************************
*/

/*
 * compile with:
 *
 * cc -I /usr/X11R6/include -o xswitchres xswitchres.c -L /usr/X11R6/lib -lXxf86vm -lXext -lX11
 *
 */

#include <X11/X.h>
#include <X11/Xlib.h>

#include <X11/extensions/xf86vmode.h>

#include <stdio.h>

extern int errno;

static char *progname;

void usage() {
  fprintf(stderr,"%s: usage: xswitchres [-v] <x-res>x<y-res>\n",progname);
}

int main(int argc, char *argv[]) {

  char *res = NULL;
  int verbose = 0;
  int i;

  Display *display;
  int screen;
  int major;
  int minor;
  int nmodes;
  XF86VidModeModeInfo **modes;

  progname = argv[0];

  if (argc > 3) {
    usage();
    exit(-1);
  }

  for (i=1; i<argc; i++) {
    if (!strcmp(argv[i],"-v"))
      verbose = 1;
    else if (argv[i][0] == '-')
      usage(), exit(-1);
    else
      res = argv[i];
  }

  display = XOpenDisplay(NULL);
  if (!display) {
    fprintf(stderr,"%s: can't open display (%s)\n",progname,strerror(errno));
    exit(-1);
  }
  screen = DefaultScreen(display);

  if (!XF86VidModeQueryVersion(display,&major,&minor)) {
    fprintf(stderr,"%s: can't find VidMode extension (%s)\n",progname,strerror(errno));
    exit(-1);
  }

  if (verbose)
    fprintf(stderr,"%s: VidModeExtension: version %d.%d\n",progname,major,minor);

  if (!XF86VidModeGetAllModeLines(display,screen,&nmodes,&modes)) {
    fprintf(stderr,"%s: can't find modelines (%s)\n",progname,strerror(errno));
    exit(-1);
  }

  if (verbose) {
    int i;

    fprintf(stderr,"%s: found %d modelines\n",progname,nmodes);

    for (i=0; i<nmodes; i++) {
      fprintf(stderr,"%s: mode %d: %dx%d\n",progname,i,modes[i]->hdisplay,modes[i]->vdisplay);
    }
  }

  if (res) {
    int x,y;

    if (sscanf(res,"%dx%d",&x,&y) != 2) {
      fprintf(stderr,"%s: can't parse \"%s\" as a resolution\n",progname,res);
      exit(-1);
    }

    if (verbose)
      fprintf(stderr,"%s: requested resolution %dx%d\n",progname,x,y);

    for (i=0; i<nmodes; i++) {
      if (x == modes[i]->hdisplay && y == modes[i]->vdisplay) {

        if (verbose)
          fprintf(stderr,"%s: switching to mode %d (%dx%d)\n",progname,i,x,y);

        if (!XF86VidModeSwitchToMode(display,screen,modes[i])) {
          fprintf(stderr,"%s: failed to switch to mode %d (%dx%d) (%s)\n",progname,i,x,y,strerror(errno));
          exit(-1);
        }

        XSync(display,False);

        exit(0);
      }
    }

    fprintf(stderr,"%s: can't find mode matching \"%s\"\n",progname,res);
    exit(-1);

  }

  exit(0);
}
