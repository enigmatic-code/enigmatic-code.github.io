/* -*-C-*-
*******************************************************************************
*
* File:         xascend.c
* RCS:          $Header: $
* Description:  Monitor an Ascend Pipeline 50
* Author:       Jim Randell
* Created:      Mon Feb  3 14:52:41 1997
* Modified:     Mon Feb 24 11:51:22 1997 (Jim Randell) jim_randell@iname.com
* Language:     C
* Package:      N/A
* Status:       Experimental (Do Not Distribute)
*
* (C) Copyright 1997, Hewlett-Packard Company, all rights reserved.
*
*******************************************************************************
*/

/*
 *  For a full list of VT100 codes see "vt100.h".
 *
 *  The one's we're interested in are:
 *
 *  ESC [ 2 J        -  Erase entire screen, but do not move cursor
 *  ESC [ H          -  Cursor home
 *  ESC [ %d ; %d H  -  Move cursor to line $1, column $2
 *
 *  And ignore everything else (specifically...)
 *
 *  ESC ( 0          -  Line Drawing
 *  ESC [ 7 m        -  Inverse video on
 *  ESC ( B          -  North American ASCII Set (cancels line drawing)
 *  ESC [ 0 m        -  Clear all character attributes
 */

#define DEBUG(X)

#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Intrinsic.h>

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

#include <errno.h>
#include <string.h>

void die(int);

static pid_t slave = -1;

static int log = False;
static int log_fd = -1;

static int clu = 0;     /* current line usage (%) */
static int alu = 0;     /* average line usage (%) */
static int bw = 0;      /* bandwidth (Kbits/s) */
static char b1 = '-';   /* status of B1 channel (*,d,r,.,-) */
static char b2 = '-';   /* status of B2 channel (*,d,r,.,-) */
static char uptime[12]; /* uptime (hh:mm:ss or dd:hh:mm) */

static int x = 0;
static int y = 0;

#define COLUMNS 80
#define ROWS 24

static char screen[COLUMNS][ROWS];

#define NUL '\0'
#define ESC '\033'
#define SPC ' '

#define read_char(x,y) (screen[(x)][(y)])

int read_number(int x,int y) {
  int n = 0;
  char c;

  /* skip leading spaces */
  while (c = read_char(x,y), c == SPC)
    x++;

  while ('0' <= c && c <= '9') {
    n *= 10;
    n += c - '0';
    c = read_char(++x,y);
  }

  return n;
}

void read_string(int x, int y, char *string, int n) {
  for (;n>0;n--)
    *string++ = read_char(x++,y);
  *string = NUL;
}

void move(int line,int column) {
  x = column;
  y = line;
  DEBUG(fprintf(stderr,"[move<%d,%d>]",x,y));
}

void clear() {
  int i;
  int j;
  for (i=0; i<COLUMNS; i++)
    for (j=0; j<ROWS; j++)
      screen[i][j] = SPC;
  DEBUG(fprintf(stderr,"[clear]"));
}

#define EOF (-1)

int next_char(int fd) {
  ssize_t n;
  char c;
  n = read(fd,&c,sizeof(c));
  if (n == 0 || (n == -1 && errno == EWOULDBLOCK))
    return EOF;
  if (n == -1) {
    fprintf(stderr,"read failed (read: %s, errno=%d). exiting\n",strerror(errno),errno);
    die(True);
  }
  if (log)
    write(log_fd,&c,sizeof(c));
  return c;
}

static enum {
  Initial,
  Escape,
  EscapeBracket,
  EscapeSomethingElse,
  ReadArg1,
  ReadArg2
} state = Initial;

void process_vt100(int fd) {
  int arg1;
  int arg2;
  int c;

  while (c = next_char(fd), c != EOF) {

    switch (state) {

    case Initial:
      if (c == ESC) {
        /* we've seen an escape character */
        state = Escape;
      } else {
        /* insert the character into the "screen" */
        /* really we should deal with returns, backspaces etc. here */
        screen[x][y] = c;
        if (++x == COLUMNS) {
          x = 0;
          if (++y == ROWS)
            y = 0;
        }
      }
      break;

    case Escape:
      /* we've seen an escape character, decide what to do next... */
      if (c == '[') {
        /* this is what we're interested in */
        state = EscapeBracket;
      } else {
        state = EscapeSomethingElse;
      }
      break;

    case EscapeBracket:
      arg1 = arg2 = 0;
      state = ReadArg1;
      /* fall through to read the first arg... */

    case ReadArg1:
      switch (c) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
        /* read the argument */
        arg1 *= 10; arg1 += c - '0';
        break;
      case ';':
        /* there's another argument to read, so do that */
        state = ReadArg2;
        break;
      case 'H':
        /* ESC [ H  -  cursor home */
        move(0,0);
        state = Initial;
        break;
      case 'J':
        /* ESC 2 J  -  erase screen */
        if (arg1 == 2)
          clear();
        state = Initial;
        break;
      case 'm':
        /* ESC %d m  - attribute processing... ignore */
      default:
        /* go back to state initial */
        state = Initial;
        break;
      }
      break;

    case ReadArg2:
      switch (c) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
        /* read the argument */
        arg2 *= 10; arg2 += c - '0';
        break;
      case 'H':
        /* ESC [ %d ; %d H  -  move cursor */
        if (0 < arg1 && --arg1 < ROWS && 0 < arg2 && --arg2 < COLUMNS)
          move(arg1,arg2);
        /* fall through to reset state */
      default:
        /* go back to state initial */
        state = Initial;
        break;
      }
      break;

    case EscapeSomethingElse:
      /* ESC ( %c, ESC ) %c, ESC # %c  -  ignore */
      state = Initial;
      break;
    }
  }
}

void ascend_status() {

  b1 = read_char(42,4);
  b2 = read_char(42,5);

  clu = read_number(63,10);
  alu = read_number(73,10);
  bw = read_number(59,9);

  read_string(69,8,uptime,8);

  DEBUG(fprintf(stdout,"B1=%c B2=%c BW=%dK CLU=%d%% ALU=%d%% UPTIME=%s\n",b1,b2,bw,clu,alu,uptime));
}

static char *classname = "XAscend";
static char *progname = "xascend";

static char *version = "V0.0";

static XtAppContext app_context;
static Display *display = NULL;
static Window window = None;
static Pixmap pixmap = None;
static GC gc;
static XFontStruct *font = NULL;
static unsigned int depth;

/* the following are settable values */

static char *connect_cmd = NULL;

static unsigned int width = 140;
static unsigned int height = 90;

static float border_offset;

static float bar_width;

static char *font_name;

#define NCOLOURS (5)

static char *colour_name[NCOLOURS];

static char *clu_label;
char *alu_label;

char *hostname = NULL;

float clu_offset;
float alu_offset;
float bw_offset;

float led_offset;
float b1_offset;
float b2_offset;

static int bar_height;
static int bar_separation;

static int font_sizes[] = { 8, 10, 12, 14, 18, 20, 24, 34, 40, 50, 60, 72, 144 };

#define NFONTSIZES (sizeof(font_sizes)/sizeof(font_sizes[0]))

static int current_font_size;

static unsigned long pixel[NCOLOURS];

#define BG      (pixel[0])
#define OFF     (pixel[1])
#define ON      (pixel[2])
#define PENDING (pixel[3])
#define DOWN    (pixel[4])

/* these are derived values */

static int border;
static int clu_pos;
static int alu_pos;
static int bw_pos;
static int led_pos;
static int b1_pos;
static int b2_pos;
static int ascent;
static int led_size;
static int bar_length;

void update_display();

/* X11 resource stuff */

static XrmOptionDescRec options [] = {
  { "-font-spec",       ".font-spec",           XrmoptionSepArg },
  { "-font-size",       ".font-size",           XrmoptionSepArg },

  { "-clu-label",       ".clu-label",           XrmoptionSepArg },
  { "-alu-label",       ".alu-label",           XrmoptionSepArg },
  { "-ascend-host",     ".ascend-host",         XrmoptionSepArg },

  { "-border-offset",   ".border-offset",       XrmoptionSepArg },
  { "-bar-width",       ".bar-width",           XrmoptionSepArg },

  { "-clu-offset",      ".clu-offset",          XrmoptionSepArg },
  { "-alu-offset",      ".alu-offset",          XrmoptionSepArg },
  { "-bw-offset",       ".bw-offset",           XrmoptionSepArg },
  { "-b1-offset",       ".b1-offset",           XrmoptionSepArg },
  { "-b2-offset",       ".b2-offset",           XrmoptionSepArg },
  { "-led-offset",      ".led-offset",          XrmoptionSepArg },

  { "-bg-colour",       ".bg-colour",           XrmoptionSepArg },
  { "-off-colour",      ".off-colour",          XrmoptionSepArg },
  { "-on-colour",       ".on-colour",           XrmoptionSepArg },
  { "-pending-colour",  ".pending-colour",      XrmoptionSepArg },
  { "-down-colour",     ".down-colour",         XrmoptionSepArg },

  { "-slave",           ".slave",               XrmoptionSepArg },
  { "-log",             ".log",                 XrmoptionNoArg, "True" }
};

#define NOPTIONS (sizeof(options)/sizeof(options[0]))

static char *defaults[] = {
  "xascend.geometry: 140x90",

  "xascend.font-spec: -*-helvetica-bold-r-*-*-%d-*-*-*-*-*-iso8859-1",
  "xascend.font-size: 10",

  "xascend.clu-label: CLU",
  "xascend.alu-label: ALU",

  "xascend.border-offset: 0.02",
  "xascend.bar-width: 0.15",

  "xascend.clu-offset: 0.15",
  "xascend.alu-offset: 0.40",
  "xascend.bw-offset: 0.75",
  "xascend.b1-offset: 0.65",
  "xascend.b2-offset: 0.85",
  "xascend.led-offset: 0.50",

  "xascend.bg-colour: black",
  "xascend.off-colour: green4",
  "xascend.on-colour: green",
  "xascend.pending-colour: orange2",
  "xascend.down-colour: red2",

  "xascend.slave: telnet \"%s\"",
  "xascend.log: False",

  NULL
};


char *get_string_resource(XrmDatabase db, char *name, char *class) {
  char fqc[512];
  char fqn[512];
  char *type;
  XrmValue value;

  sprintf(fqc,"%s.%s",classname,class);
  sprintf(fqn,"%s.%s",progname,name);

  if (XrmGetResource(db,fqn,fqc,&type,&value)) {
    return (char *) value.addr;
  } else {
    return NULL;
  }
}

int get_integer_resource(XrmDatabase db, char *name, char *class) {
  char *str;
  str = get_string_resource(db,name,class);
  if (str != NULL)
    return atoi(str);
  else
    return 0;
}

double get_float_resource(XrmDatabase db, char *name, char *class) {
  char *str;
  str = get_string_resource(db,name,class);
  if (str != NULL) {
    double d;
    sscanf(str,"%lf",&d);
    return d;
  } else
    return 0.0;
}

#include <ctype.h>

int strcmpi(char *s1, char *s2) {
  char *p = s1;
  char *q = s2;
  int r;
  while (p && q && *p != NUL && *q != NUL)
    if ((r = _tolower(*q++) - _tolower(*p++)) != 0)
      return r;
  return (_tolower(*q++) - _tolower(*p++));
}

#define streqi(X,Y) (!(strcmpi((X),(Y))))

int get_boolean_resource(XrmDatabase db, char *name, char *class) {
  char *str;
  str = get_string_resource(db,name,class);
  if (str != NULL && (streqi(str,"true") || streqi(str,"on") || streqi(str,"yes")))
    return True;
  else
    return False;
}

int x_error_handler(Display *dpy, XErrorEvent *event) {
  die(True);
  return 0;
}

int x_io_error_handler(Display *dpy) {
  die(True);
  return 0;
}

void xinit(int *argc, char *argv[]) {
  char *display_name = NULL;
  Window root;
  Screen *screen;
  Colormap cmap;
  XrmDatabase db;
  int i;
  XColor colour;
  XSetWindowAttributes xswa;
  unsigned long valuemask;
  XGCValues xgcv;
  char *geometry;
  int x;
  int y;
  unsigned int w;
  unsigned int h;
  int xpos = 0;
  int ypos = 0;
  char xlfd[128];

  XSetErrorHandler(x_error_handler);
  XSetIOErrorHandler(x_io_error_handler);

  XtToolkitInitialize();
  app_context = XtCreateApplicationContext();
  XtAppSetFallbackResources(app_context,defaults);

  display = XtOpenDisplay(app_context,display_name,progname,classname,options,NOPTIONS,argc,argv);
  if (display == NULL) {
    fprintf(stderr,"can't open display\n");
    die(True);
  }

  db = XtDatabase(display);

  font_name = get_string_resource(db,"font-spec","FontSpec");
  current_font_size = get_integer_resource(db,"font-size","FontSize");
  clu_label = get_string_resource(db,"clu-label","CluLabel");
  alu_label = get_string_resource(db,"alu-label","AluLabel");
  hostname = get_string_resource(db,"ascend-host","AscendHost");

  border_offset = get_float_resource(db,"border-offset","BorderOffset");
  bar_width = get_float_resource(db,"bar-width","BarWidth");

  clu_offset = get_float_resource(db,"clu-offset","CluOffset");
  alu_offset = get_float_resource(db,"alu-offset","AluOffset");
  bw_offset = get_float_resource(db,"bw-offset","BwOffset");
  b1_offset = get_float_resource(db,"b1-offset","B1Offset");
  b2_offset = get_float_resource(db,"b2-offset","B2Offset");
  led_offset = get_float_resource(db,"led-offset","LedOffset");
  
  colour_name[0] = get_string_resource(db,"bg-colour","Background");
  colour_name[1] = get_string_resource(db,"off-colour","Background");
  colour_name[2] = get_string_resource(db,"on-colour","Foreground");
  colour_name[3] = get_string_resource(db,"pending-colour","Foreground");
  colour_name[4] = get_string_resource(db,"down-colour","Foreground");

  connect_cmd = get_string_resource(db,"slave","Slave");
  log = get_boolean_resource(db,"log","Log");
  DEBUG(fprintf(stderr,"connect_cmd = \"%s\" log = %s\n",connect_cmd,log?"True":"False"));

  geometry = get_string_resource(db,"geometry","Geometry");
  i = XParseGeometry(geometry,&x,&y,&w,&h);
  if (i&XValue) xpos = x;
  if (i&YValue) ypos = y;
  if (i&WidthValue) width = w;
  if (i&HeightValue) height = h;
  DEBUG(fprintf(stderr,"xpos=%d ypos=%d width=%d height=%d\n",xpos,ypos,width,height));
  
  screen = DefaultScreenOfDisplay(display);
  root = RootWindowOfScreen(screen);
  cmap = DefaultColormapOfScreen(screen);
  depth = DefaultDepthOfScreen(screen);

  /* find the font */
  sprintf(xlfd,font_name,current_font_size);
  font = XLoadQueryFont(display,xlfd);
  if (font == NULL) {
    fprintf(stderr,"can't load font \"%s\"\n",xlfd);
  }

  /* allocate the colours (read only) */
  for (i=0; i<NCOLOURS; i++) {
    if (!XParseColor(display,cmap,colour_name[i],&colour))
      fprintf(stderr,"can't parse colour name \"%s\"\n",colour_name[i]);
    XAllocColor(display,cmap,&colour);
    pixel[i] = colour.pixel;
    DEBUG(fprintf(stderr,"colour %s = %ld\n",colour_name[i],pixel[i]));
  }

  valuemask = CWBackPixel;
  xswa.background_pixel = BG;

  /* create the window */
  window = XCreateWindow(display,root,
                         xpos,ypos,width,height,
                         0,
                         CopyFromParent,
                         InputOutput,
                         CopyFromParent,
                         valuemask,
                         &xswa);

  /* create the pixmap (for double buffering) */
  pixmap = XCreatePixmap(display,window,width,height,depth);

  /* create the graphics context */
  valuemask = GCBackground | GCFont;
  xgcv.background = BG;
  xgcv.font = font->fid;
  gc = XCreateGC(display,window,valuemask,&xgcv);

  /* set the window title */
  sprintf(xlfd,"%s %s",classname,version);
  XChangeProperty(display,window,XA_WM_NAME,XA_STRING,8,PropModeReplace,(unsigned char *) xlfd,strlen(xlfd));
  XChangeProperty(display,window,XA_WM_CLASS,XA_STRING,8,PropModeReplace,(unsigned char *) classname,strlen(classname));

  /* ask to be notified of key presses and exposures */
  XSelectInput(display,window,StructureNotifyMask | ExposureMask | KeyPressMask);

  XMapWindow(display,window);
}

void set_parameters(unsigned int w, unsigned int h) {
  int t;
  int font_size;
  int i;
  char xlfd[128];
  XFontStruct *f;

  if (width != w || height != h) {
    if (pixmap != None)
      XFreePixmap(display,pixmap);
    pixmap = XCreatePixmap(display,window,w,h,depth);
  }
  width = w;
  height = h;
  border = width * border_offset + 1;
  clu_pos = width * clu_offset;
  alu_pos = width * alu_offset;
  bw_pos = width * bw_offset;
  led_pos = height * led_offset;
  b1_pos = width * b1_offset;
  b2_pos = width * b2_offset;
  font_size = width * 0.07143;
  t = height * 0.1112;
  if (t < font_size)
    font_size = t;
  for (i=0; i<=NFONTSIZES; i++)
    if (font_size <= font_sizes[i])
      break;
  if (font_size != current_font_size) {
    sprintf(xlfd,font_name,font_sizes[i]);
    f = XLoadQueryFont(display,xlfd);
    if (f != NULL) {
      XFreeFont(display,font);
      font = f;
      XSetFont(display,gc,font->fid);
    }
  }
  ascent = font->max_bounds.ascent;
  led_size = width * 0.1143;
  t = height * 0.1778;
  if (t < led_size)
    led_size = t;
  bar_length = width * bar_width;
  bar_height = 0.01429 * height + 1;
  bar_separation = bar_height + 0.007143 * height + 1;
}

void draw_label(Drawable window, int x, int y, char *label) {
  int length;
  int text_width;
  length = strlen(label);
  text_width = XTextWidth(font,label,length);
  XDrawImageString(display,window,gc,x-text_width/2,y,label,length);
}

void draw_bars(Drawable window, int pos, int nbars, int y) {
  int i;
  for (i=0; i<nbars; i++) {
    XFillRectangle(display,window,gc,pos-bar_length/2,y,bar_length,bar_height);
    y -= bar_separation;
  }
}

void draw_bargraph(Drawable window, int pos, char *label, int value) {
  int nbars;
  char buffer[8];

  /* do the off drawing */
  XSetForeground(display,gc,OFF);

  /* draw the off bars */
  nbars = (height - 2*ascent - 4*border)/bar_separation - 1;
  draw_bars(window,pos,nbars,height - ascent - 2*border - bar_height);

  /* do the ON drawing */
  XSetForeground(display,gc,ON);

  /* draw the label */
  draw_label(window,pos,border+ascent,label);

  /* draw the value */
  sprintf(buffer,"%d%%",value);
  draw_label(window,pos,height-border,buffer);

  /* draw the on bars */
  nbars *= value;
  nbars /= 100;
  draw_bars(window,pos,nbars,height - ascent - 2*border - bar_height);
}

void draw_led(Drawable window, int x, int y, int d, char state) {
  int r = d/2;
  unsigned long pix;

  switch(state) {
  case '*': /* CONNECTED */
    pix = ON;
    break;
  case 'd': /* DIALLING (outgoing call) */
  case 'r': /* RINGING (incoming call) */
    pix = PENDING;
    break;
  case '.': /* UNAVAILABLE */
    pix = DOWN;
    break;
  case '-': /* IDLE (but in service) */
  default:
    pix = OFF;
    break;
  }
  
  XSetForeground(display,gc,pix);
  XFillArc(display,window,gc,x-r,y-r,d,d,0,360*64);
}

void update_display() {
  char buffer[12];

  /* clear the pixmap */
  XSetForeground(display,gc,BG);
  XFillRectangle(display,pixmap,gc,0,0,width,height);

  /* draw the CLU graph */
  draw_bargraph(pixmap,clu_pos,clu_label,clu);

  /* draw the ALU graph */
  draw_bargraph(pixmap,alu_pos,alu_label,alu);

  XSetForeground(display,gc,ON);

  draw_label(pixmap,bw_pos,border+ascent,hostname);

  sprintf(buffer,"%dK",bw);
  draw_label(pixmap,bw_pos,led_pos+led_size+2*border,buffer);

  draw_label(pixmap,b1_pos,led_pos-led_size/2-ascent/2,"1");
  draw_label(pixmap,b2_pos,led_pos-led_size/2-ascent/2,"2");

  draw_label(pixmap,bw_pos,height-border,uptime);

  draw_led(pixmap,b1_pos,led_pos,led_size,b1);
  draw_led(pixmap,b2_pos,led_pos,led_size,b2);

  /* copy the pixmap to the window */
  XCopyArea(display,pixmap,window,gc,0,0,width,height,0,0);
}

static int in[2];
static int out[2];

void ascend_connect() {
  char *shell;
  int argc = 0;
  char *argv[4];
  char exec_space[] = { 'e', 'x', 'e', 'c', ' ' }; /* no terminating NUL */
  char *cmd;

  /* set up the shell */
  shell = getenv("SHELL");
  if (shell == NULL)
    shell = "/bin/sh";

  /* create the pipes */
  if (pipe(in) == -1 || pipe(out) == -1) {
    fprintf(stderr,"can't create pipes. exiting\n");
    die(True);
  }

  switch (slave = fork()) {

  case -1:
    fprintf(stderr,"can't create slave process (fork: %s)\n",strerror(errno));
    die(True);

  case 0:
    /* we are the child process */

    /* make ourselves a process leader */
    setsid();

    /* close inherited stdin and connect stdin to the pipe */
    close(STDIN_FILENO);
    dup(in[0]);

    /* close inherited stdout and connect stdout to the pipe */
    close(STDOUT_FILENO);
    dup(out[1]);

    /* set up the slave commands */
    argv[argc++] = shell;
    argv[argc++] = "-c";
    cmd = malloc(sizeof(exec_space)+strlen(connect_cmd)+strlen(hostname));
    strncpy(cmd,exec_space,sizeof(exec_space));
    sprintf(cmd+sizeof(exec_space),connect_cmd,hostname);
    argv[argc++] = cmd;
    argv[argc] = NULL;

    /* execute the process */
    DEBUG(fprintf(stderr,"executing... %s %s \"%s\"\n",argv[0],argv[1],argv[2]));
    execv(argv[0],argv);

    /* we only get this far if the exec failed */
    fprintf(stderr,"can't exec slave process \"%s\" (execv: %s)\n",connect_cmd,strerror(errno));
    die(True);
  }

  /* only the parent process gets this far */

  /* set the stdout from the slave process to be non-blocking */
  if (fcntl(out[0],F_SETFL,O_NDELAY) == -1)
    fprintf(stderr,"can't set non-blocking option for slave output (fcntl: %s)\n",strerror(errno));
}

static char quit_bytes[] = { '\04', 'c', '\n' };
static char refresh_bytes[] = { '\014' };

void send(char *bytes, int nbytes) {
  write(in[1],bytes,nbytes);
  if (log)
    write(log_fd,bytes,nbytes);
}

void quit() {
  /* write '^DC' to the slave process */
  DEBUG(fprintf(stderr,"sending quit sequence to slave... "));
  send(quit_bytes,sizeof(quit_bytes)/sizeof(quit_bytes[0]));
  DEBUG(fprintf(stderr,"done\n"));
}

void refresh() {
  /* write '^L' to the slave process */
  DEBUG(fprintf(stderr,"sending refresh sequence to slave... "));
  send(refresh_bytes,sizeof(refresh_bytes)/sizeof(refresh_bytes[0]));
  DEBUG(fprintf(stderr,"done\n"));
}

void slave_driver(XtPointer data, int *source, XtInputId *id) {
  process_vt100(*source);
  ascend_status();
  update_display();
}

void signal_handler(int sig) {
  if (sig == SIGCLD)
    slave = -1;
  die(True);
}

void die(int and_exit) {
  fprintf(stderr,"exiting...\n");

  /* clean up the slave process... */
  if (slave != -1) {
    struct sigaction action;
    sigset_t mask;
    pid_t pid;
    int status;

    /* ignore death of child... */
    sigemptyset(&mask);
    action.sa_handler = SIG_IGN;
    action.sa_mask = mask;
    action.sa_flags = 0;
    sigaction(SIGCLD,&action,NULL);

    /* send the quit sequence to the slave process */
    quit();
    /* give it a second to shutdown... */
    sleep(1);
    /* see if it's died */
    pid = waitpid(slave,&status,WNOHANG);
    if (pid == 0) {
      /* slave has not exited, kill it (nicely) */
      fprintf(stderr,"sending SIGTERM to slave...\n");
      if (kill(slave,SIGTERM) == 0) {
        /* give it a second to shutdown... */
        sleep(1);
        /* see if it's died */
        pid = waitpid(slave,&status,WNOHANG);
        if (pid == 0) {
          /* kill it for sure */
          fprintf(stderr,"sending SIGKILL to slave...\n");
          if (kill(slave,SIGKILL) == 0) {
            /* give it a second to shutdown... */
            sleep(1);
            /* see if it's died */
            pid = waitpid(slave,&status,WNOHANG);
          }
        }
      }
    }
    if (pid != 0)
      fprintf(stderr,"slave exited with code %d [EXITED:%d STATUS:%d SIGNALLED:%d SIG:%d]\n",
              status,
              WIFEXITED(status)?1:0,WEXITSTATUS(status),WIFSIGNALED(status)?1:0,WTERMSIG(status));
  }

  /* free X11 resources */
  if (font != NULL)
    XFreeFont(display,font);
  if (pixmap != None)
    XFreePixmap(display,pixmap);
  if (window != None)
    XDestroyWindow(display,window);
  if (display != NULL)
    XtCloseDisplay(display);

  /* close log */
  if (log)
    close(log_fd);

  if (and_exit)
    exit(1);
}

void handle_keypress(char key) {
  switch (key) {
  case 'q':
  case 'Q':
  case '\03': /* ^C */
  case '\04': /* ^D */
    /* quit */
    die(True);
    break;
  case 'r':
  case 'R':
  case '\014': /* ^L */
    /* refresh */
    refresh();
    break;
  }
}

int signals[] = { SIGHUP, SIGINT, SIGTERM, SIGCLD };

#define NSIGNALS (sizeof(signals)/sizeof(signals[0]))

void main(int argc, char *argv[]) {
  struct sigaction action;
  sigset_t mask;
  int i;

  xinit(&argc,argv);

  DEBUG(
    for (i=0; i<argc; i++)
    fprintf(stderr,"argv[%d] = \"%s\"\n",i,argv[i]);
  );
  
  if (argc > 1)
    hostname = argv[1];

  if (hostname == NULL) {
    fprintf(stderr,"usage: %s [<xargs>] <hostname-of-ascend-pipeline>\n",argv[0]);
    die(True);
  }

  if (log)
    log_fd = open("ascend.log",O_CREAT|O_TRUNC|O_WRONLY,0666);

  /* set up handlers for the signals */
  sigemptyset(&mask);
  action.sa_handler = signal_handler;
  action.sa_mask = mask;
  action.sa_flags = 0;
  
  for (i=0; i<NSIGNALS; i++)
    sigaction(signals[i],&action,NULL);

  ascend_connect();

  /* register a handler for output from the slave process */
  XtAppAddInput(app_context,out[0],(XtPointer) XtInputReadMask,slave_driver,NULL);

  set_parameters(width,height);

  for (;;) {
    XEvent event;
    char key;
    XtAppNextEvent(app_context,&event);
    switch (event.type) {
    case Expose:
      DEBUG(fprintf(stderr,"window exposed...\n"));
      update_display();
      break;
    case ConfigureNotify:
      DEBUG(fprintf(stderr,"window resized [%d,%d]...\n",event.xconfigure.width,event.xconfigure.height));
      set_parameters(event.xconfigure.width,event.xconfigure.height);
      break;
    case KeyPress:
      XLookupString((XKeyEvent *) &event,&key,sizeof(key),NULL,NULL);
      DEBUG(fprintf(stderr,"key press [%c]...\n",key));
      handle_keypress(key);
      break;
    }
    XtDispatchEvent(&event);
  }
}

/*
 * TODO:
 *
 * ability to set screen scraper parameters
 *
 *
 * DONE:
 *
 * Xlib cleanup (display, font, pixmap) in die()
 * window repaints (on expose) and resize
 * double buffering
 * sending '^DC' to terminate telnet (and maybe '^L' to repaint)
 * xresource/cmd line argument handling
 * kill the telnet when window is closed, or app is sent SIGINT (etc)
 *
 */
